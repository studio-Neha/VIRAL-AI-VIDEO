import os
import pickle
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

def upload_to_youtube_shorts(video_path, title, description, tags=None):
    """
    Uploads the generated 9:16 MP4 directly to YouTube Shorts using client_secrets.json.
    """
    if not os.path.exists("client_secrets.json"):
        print("[YouTube Auto-Post] 'client_secrets.json' not found. Skipping YouTube upload (Video saved locally).")
        return None

    creds = None
    if os.path.exists("youtube_token.pickle"):
        with open("youtube_token.pickle", "rb") as token:
            creds = pickle.load(token)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("client_secrets.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("youtube_token.pickle", "wb") as token:
            pickle.dump(creds, token)

    youtube = build("youtube", "v3", credentials=creds)

    if "#shorts" not in title.lower():
        title = f"{title[:85]} #Shorts"

    body = {
        "snippet": {
            "title": title[:100],
            "description": description,
            "tags": tags or ["shorts", "viral", "facts", "techindia", "trending"],
            "categoryId": "28"
        },
        "status": {
            "privacyStatus": "public",
            "selfDeclaredMadeForKids": False
        }
    }

    media = MediaFileUpload(video_path, chunksize=-1, resumable=True, mimetype="video/mp4")
    request = youtube.videos().insert(part="snippet,status", body=body, media_body=media)
    
    print("[YouTube Auto-Post] Uploading video to YouTube Shorts...")
    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            print(f"[YouTube Auto-Post] Uploaded {int(status.progress() * 100)}%")

    video_id = response.get("id")
    print(f"[YouTube Auto-Post] SUCCESS! Live at: https://youtube.com/shorts/{video_id}")
    return video_id
