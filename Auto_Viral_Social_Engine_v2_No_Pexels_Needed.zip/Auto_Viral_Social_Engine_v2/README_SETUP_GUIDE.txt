========================================================================
   AUTO-VIRAL SOCIAL MEDIA ENGINE v2 (NO PEXELS KEY NEEDED!)
========================================================================

Pexels ne filhal naye API keys dena pause kar diya hai. Isliye is v2 ZIP
mein humne **Zero-Key AI Visual Engine (Pollinations.ai)** aur **Pixabay
Video API** dono built-in jod diye hain!

Ab aapko video banane ke liye KISI BHI Video API Key ki zaroorat nahi hai!

------------------------------------------------------------------------
STEP 1: 1-CLICK INSTALLATION (TURANT MP4 BANAYEGA)
------------------------------------------------------------------------
1. Is ZIP ko Extract karein aur "INSTALL_AND_RUN_WINDOWS.bat" par double-click karein.
2. Yeh bina kisi API key ke bhi turant AI scenes generate karega, Hinglish
   voiceover banayega, aur 1080x1920 MP4 video "daily_viral_output" mein
   save kar dega!

------------------------------------------------------------------------
STEP 2: SIRF 1 FREE KEY DALEIN (.env File Mein)
------------------------------------------------------------------------
1. ".env" file ko Notepad mein kholein.
2. Sirf "GEMINI_API_KEY" (https://aistudio.google.com/ se free lein) paste karein.
3. (Optional) Agar aapko AI Images ke bajaye Stock Videos chahiye, toh
   https://pixabay.com/api/docs/ par login karke 1 second mein free
   "PIXABAY_API_KEY" copy karein aur .env mein daal dein!
========================================================================
