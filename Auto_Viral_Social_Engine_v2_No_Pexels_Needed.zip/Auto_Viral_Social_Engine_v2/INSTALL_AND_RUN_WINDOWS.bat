@echo off
title Auto-Viral Social Media Engine v2 - 1-Click Installer
echo =====================================================================
echo   AUTO-VIRAL SOCIAL MEDIA ENGINE v2 (NO PEXELS KEY REQUIRED!)
echo =====================================================================
echo.
echo [Step 1/3] Checking Python installation...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not added to PATH!
    echo Please install Python 3.11+ from https://www.python.org/downloads/
    echo Make sure to tick "Add Python to PATH" during installation.
    pause
    exit /b
)

echo [Step 2/3] Creating virtual environment and installing free libraries...
if not exist "venv" (
    python -m venv venv
)
call venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt

echo.
echo [Step 3/3] Generating your first FULL 1080x1920 MP4 Video right now...
python auto_viral_engine.py

echo.
echo =====================================================================
echo   INSTALLATION COMPLETE!
echo   - Your first full MP4 video is ready in 'daily_viral_output'!
echo   - Open '.env' in Notepad and paste ONLY your GEMINI_API_KEY
echo     (from https://aistudio.google.com/) for daily live trend scripts!
echo =====================================================================
pause
