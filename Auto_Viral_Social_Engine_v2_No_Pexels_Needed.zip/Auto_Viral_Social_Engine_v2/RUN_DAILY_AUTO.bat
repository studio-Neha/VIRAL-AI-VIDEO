@echo off
title Auto-Viral Social Media Engine v2 - Running
call venv\Scripts\activate
python auto_viral_engine.py
echo.
echo Done! Check the 'daily_viral_output' folder for your MP4 video.
pause
