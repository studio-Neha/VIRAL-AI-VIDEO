import os
import json
import asyncio
import urllib.parse
import requests
import feedparser
from datetime import datetime
from dotenv import load_dotenv
from google import genai
from google.genai import types
import edge_tts
import PIL.Image
if not hasattr(PIL.Image, "ANTIALIAS"):
    PIL.Image.ANTIALIAS = PIL.Image.LANCZOS
from moviepy.editor import VideoFileClip, ImageClip, AudioFileClip, concatenate_videoclips
from youtube_uploader import upload_to_youtube_shorts

# Load environment variables from .env file
load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "YOUR_FREE_GEMINI_API_KEY")
PIXABAY_API_KEY = os.getenv("PIXABAY_API_KEY", "")
PEXELS_API_KEY = os.getenv("PEXELS_API_KEY", "")
IG_USER_ID = os.getenv("IG_USER_ID", "")
FB_PAGE_ID = os.getenv("FB_PAGE_ID", "")
META_ACCESS_TOKEN = os.getenv("META_ACCESS_TOKEN", "")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
GEO_REGION = os.getenv("GEO_REGION", "IN")
VOICE_NAME = os.getenv("VOICE_NAME", "hi-IN-MadhurNeural")

OUTPUT_DIR = "daily_viral_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)


# =====================================================================
# STAGE 1: AUTO-SEARCH DAILY VIRAL TRENDS (Google Trends RSS)
# =====================================================================
def fetch_daily_viral_trends(geo="IN", limit=10):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Stage 1: Scanning real-time viral trends in {geo}...")
    rss_url = f"https://trends.google.com/trending/rss?geo={geo}"
    feed = feedparser.parse(rss_url)
    
    trends = []
    for entry in feed.entries[:limit]:
        title = entry.get("title", "")
        traffic = entry.get("ht_approx_traffic", "High Volume")
        news_snippet = entry.get("summary", "")
        trends.append(f"Topic: {title} (Volume: {traffic}) | Context: {news_snippet}")
    
    if not trends:
        trends = [
            "Topic: Next-Gen AI Automation & Future Tech | Context: Viral technology breakthrough",
            "Topic: World's Most Extreme Mega-Engineering Projects | Context: Viral engineering facts",
            "Topic: Hidden Smartphone Security Settings You Must Know | Context: Daily tech utility"
        ]
    return trends


# =====================================================================
# STAGE 2: AI VIRAL SCRIPT, HOOK & SEO GENERATOR (Gemini Free API)
# =====================================================================
def generate_viral_package(trends_list):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Stage 2: Generating high-retention viral script & SEO metadata...")
    if not GEMINI_API_KEY or GEMINI_API_KEY == "YOUR_FREE_GEMINI_API_KEY":
        print("[Notice] GEMINI_API_KEY not set in .env! Using built-in demo viral script so you can test immediately.")
        return {
            "selected_topic": "AI & Mega-Engineering Facts",
            "viral_title": "Yeh AI System Duniya Badal Dega! 🔥 #Shorts",
            "spoken_script": "Kya aapko pata hai ki aaj ke time mein artificial intelligence sirf kuch seconds mein poora video aur design taiyaar kar sakta hai? Duniya ke bade engineers aur creators ab har roz ghanton ka kaam sirf ek click mein automate kar rahe hain. Sabse kamaal ki baat yeh hai ki yeh technology bilkul free mein available hai, aur iska sahi istemal karke aap apna poora digital workflow autopilot par chala sakte hain. Lekin...",
            "caption_and_hashtags": "Yeh AI System Duniya Badal Dega! 🔥 Follow for daily viral tech & facts. #shorts #reels #viral #techindia #facts #ai #trending #automation",
            "visual_search_queries": ["futuristic artificial intelligence glowing brain", "modern mega engineering skyscraper construction", "high tech server room neon lights", "autonomous digital automation dashboard"]
        }

    client = genai.Client(api_key=GEMINI_API_KEY)
    prompt = f"""
    You are an elite viral short-form content director for YouTube Shorts, Instagram Reels, and Facebook in India.
    Here are today's top trending topics:
    {chr(10).join(trends_list)}

    Pick the SINGLE most fascinating topic (or connect a trending topic to a mind-blowing Tech/AI/Science/World fact)
    and create a 45-second viral video package in natural HINGLISH (Hindi spoken naturally).

    Return ONLY valid JSON matching this exact structure:
    {{
      "selected_topic": "Name of topic",
      "viral_title": "Click-worthy title under 60 chars with 1 emoji",
      "spoken_script": "Full 45-second narration script. First sentence MUST be a shocking 3-second hook. Last sentence MUST loop seamlessly into the first sentence. Do NOT include stage directions or brackets, ONLY words to be spoken aloud.",
      "caption_and_hashtags": "Engaging Instagram/YouTube description + 8 viral hashtags (#shorts #reels #viral #facts #techindia etc.)",
      "visual_search_queries": [
        "cinematic vertical scene description 1",
        "cinematic vertical scene description 2",
        "cinematic vertical scene description 3",
        "cinematic vertical scene description 4"
      ]
    }}
    """

    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            temperature=0.7
        )
    )
    return json.loads(response.text)


# =====================================================================
# STAGE 3: FREE NEURAL VOICEOVER & SUBTITLES (Microsoft Edge-TTS)
# =====================================================================
async def generate_voiceover_and_subs(script_text, audio_path, srt_path):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Stage 3: Synthesizing neural voiceover ({VOICE_NAME})...")
    communicate = edge_tts.Communicate(script_text, voice=VOICE_NAME, rate="+8%")
    submaker = edge_tts.SubMaker()
    
    with open(audio_path, "wb") as audio_file:
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                audio_file.write(chunk["data"])
            elif chunk["type"] == "WordBoundary":
                submaker.feed(chunk)
                
    with open(srt_path, "w", encoding="utf-8") as srt_file:
        srt_file.write(submaker.get_srt())
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Audio ({audio_path}) & Subtitles ({srt_path}) saved!")


# =====================================================================
# STAGE 4: ZERO-KEY AI VISUALS + PIXABAY VIDEO ENGINE (NO PEXELS NEEDED!)
# =====================================================================
def fetch_visual_assets(queries, target_count=4):
    """
    3-Tier Visual Fetcher:
    Tier 1: If PIXABAY_API_KEY is provided, downloads free HD vertical stock videos from Pixabay.
    Tier 2: If PEXELS_API_KEY is provided, downloads from Pexels.
    Tier 3 (DEFAULT - ZERO API KEY REQUIRED!): Generates custom 1080x1920 vertical AI visuals via Pollinations.ai!
    """
    assets = []
    queries = queries[:target_count]

    # Tier 1: Pixabay Video API (Instant Free Key if user wants Stock Videos)
    if PIXABAY_API_KEY:
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Stage 4: Downloading HD stock videos via Pixabay API...")
        for idx, q in enumerate(queries):
            short_q = " ".join(q.split()[:3])
            url = f"https://pixabay.com/api/videos/?key={PIXABAY_API_KEY}&q={urllib.parse.quote(short_q)}&per_page=3"
            try:
                res = requests.get(url, timeout=20)
                if res.status_code == 200:
                    hits = res.json().get("hits", [])
                    if hits:
                        vid_url = hits[0]["videos"].get("medium", {}).get("url") or hits[0]["videos"].get("small", {}).get("url")
                        if vid_url:
                            local_path = os.path.join(OUTPUT_DIR, f"broll_pix_{idx}.mp4")
                            with open(local_path, "wb") as f:
                                f.write(requests.get(vid_url, timeout=30).content)
                            assets.append({"type": "video", "path": local_path})
            except Exception as e:
                print(f"[Pixabay Warning] {e}")
        if assets:
            return assets

    # Tier 2: ZERO-KEY Custom 9:16 AI Visual Generator (Works immediately out of the box!)
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Stage 4: Generating custom 1080x1920 9:16 AI scenes (No Video API Key needed!)...")
    for idx, q in enumerate(queries):
        prompt_encoded = urllib.parse.quote(f"{q}, hyperrealistic, dramatic cinematic lighting, vertical 9:16 wallpaper, 8k resolution, no text")
        img_url = f"https://image.pollinations.ai/prompt/{prompt_encoded}?width=1080&height=1920&nologo=true&seed={idx + 101}"
        local_img = os.path.join(OUTPUT_DIR, f"ai_scene_{idx}.jpg")
        try:
            r = requests.get(img_url, timeout=45)
            if r.status_code == 200:
                with open(local_img, "wb") as f:
                    f.write(r.content)
                assets.append({"type": "image", "path": local_img})
                print(f"   -> Generated Scene {idx+1}/{len(queries)}: {local_img}")
        except Exception as e:
            print(f"[AI Scene Warning] Could not fetch scene {idx+1}: {e}")

    return assets


def assemble_vertical_video(assets, audio_path, output_video_path):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Rendering final 1080x1920 MP4 Short/Reel...")
    audio_clip = AudioFileClip(audio_path)
    total_duration = audio_clip.duration
    clip_duration = total_duration / len(assets)
    
    clips = []
    for item in assets:
        if item["type"] == "video":
            clip = VideoFileClip(item["path"]).without_audio()
            if clip.duration < clip_duration:
                clip = clip.loop(duration=clip_duration)
            else:
                clip = clip.subclip(0, clip_duration)
            clip = clip.resize((1080, 1920))
        else:
            # Create a crisp 1080x1920 vertical scene from the generated AI image
            clip = ImageClip(item["path"]).set_duration(clip_duration).resize((1080, 1920))
        clips.append(clip)
        
    final_video = concatenate_videoclips(clips, method="compose")
    final_video = final_video.set_audio(audio_clip)
    final_video.write_videofile(
        output_video_path,
        fps=24,
        codec="libx264",
        audio_codec="aac",
        threads=4,
        logger=None
    )
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Final Viral Video Ready: {output_video_path}")


# =====================================================================
# STAGE 5: AUTO-PUBLISH TO YOUTUBE, INSTAGRAM, FACEBOOK & TELEGRAM
# =====================================================================
def send_telegram_notification(video_path, title, caption):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return
    print("[Telegram] Sending generated video to your Telegram...")
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendVideo"
    with open(video_path, "rb") as video_file:
        requests.post(
            url,
            data={"chat_id": TELEGRAM_CHAT_ID, "caption": f"{title}\n\n{caption[:800]}"},
            files={"video": video_file}
        )


def run_daily_viral_pipeline():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    print("=================================================================")
    print("   STARTING AUTONOMOUS SOCIAL MEDIA VIRAL ENGINE (v2 - NO PEXELS)")
    print("=================================================================")
    
    # 1. Discover Trends
    trends = fetch_daily_viral_trends(geo=GEO_REGION)
    
    # 2. Generate Viral Script & Metadata
    viral_data = generate_viral_package(trends)
    
    meta_path = os.path.join(OUTPUT_DIR, f"viral_meta_{timestamp}.json")
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(viral_data, f, indent=2, ensure_ascii=False)
        
    print(f"\n--- GENERATED VIRAL PACKAGE ---")
    print(f"Topic : {viral_data['selected_topic']}")
    print(f"Title : {viral_data['viral_title']}")
    print(f"Script: {viral_data['spoken_script']}\n")
    
    # 3. Create Voiceover & Subtitles
    audio_path = os.path.join(OUTPUT_DIR, f"voice_{timestamp}.mp3")
    srt_path = os.path.join(OUTPUT_DIR, f"subs_{timestamp}.srt")
    asyncio.run(generate_voiceover_and_subs(viral_data["spoken_script"], audio_path, srt_path))
    
    # 4. Generate Visuals (Zero-Key AI Visuals or Pixabay Videos) & Render 9:16 MP4
    queries = viral_data.get("visual_search_queries") or viral_data.get("pexels_search_queries", ["futuristic technology", "modern engineering", "digital network"])
    visual_assets = fetch_visual_assets(queries)
    if visual_assets:
        video_out = os.path.join(OUTPUT_DIR, f"FINAL_SHORT_{timestamp}.mp4")
        assemble_vertical_video(visual_assets, audio_path, video_out)
        
        # 5. Auto-Publish & Notify
        send_telegram_notification(video_out, viral_data["viral_title"], viral_data["caption_and_hashtags"])
        upload_to_youtube_shorts(
            video_out,
            title=viral_data["viral_title"],
            description=viral_data["caption_and_hashtags"]
        )


if __name__ == "__main__":
    run_daily_viral_pipeline()
